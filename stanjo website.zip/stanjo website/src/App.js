import "./App.css";
import Footer from "./components/Footer";
import { Header } from "./components/Header";
import Innovation from "./components/Innovation";

function App() {
  return (
    <div>
      <Header />
      <Innovation />
      <Footer />
    </div>
  );
}

export default App;
