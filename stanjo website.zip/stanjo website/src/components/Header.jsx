import React from "react";
import "./Header.css";
import facebook from "../images/facebookicon.svg";
import instagram from "../images/facebookicon.svg";
import arrow from "../images/chevron-down.svg";
import hamburger from "../images/hamburg.svg"

export const Header = () => {
  return (
    <header className="header">
      <div className="top-header">
        <div className="contacts-section">
          <div>
            <img src={facebook} alt="" />
            Hyderabad, INDIA
          </div>
          <div>
            <img src={facebook} alt="" />
            +91 6305858219
          </div>
          <div>
            <img src={facebook} alt="" />
            info@stanjo.in
          </div>
        </div>
        <div className="socialmedia-icons">
          <img src={facebook} alt="facebook" />
          <img src={instagram} alt="facebook" />
          <img src={facebook} alt="facebook" />
          <img src={instagram} alt="facebook" />
        </div>
      </div>
      <div className="bottom-header">
        <nav>
          
        </nav>
        <div>Home</div>
        <div>About Us | Certifications</div>
        <div className="products">
          Products
          <img src={arrow} alt=">" />
        </div>
        <div>LM79 Reports</div>
        <div>Shop</div>
        <div>Contact Us</div>
        <div>
          Calculators <img src={arrow} alt=">" />
        </div>
        <div className="header-hamburg">
          <img src={hamburger} alt="menu" />
        </div>
      </div>
    </header>
  );
};
